import 'package:employee/show.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  String _searchKey = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Search Employee")),
      body: Column(
        children: [
          TextField(
            controller: _controller,
            decoration: InputDecoration(labelText: 'Search', suffixIcon: Icon(Icons.search)),
          ),
          ElevatedButton(
            child: Text('Search'),
            onPressed: () {
              setState(() {
                _searchKey = _controller.text;
              });
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ShowData(searchKey: _searchKey)),
              );
            },
          ),
        ],
      ),
    );
  }
}