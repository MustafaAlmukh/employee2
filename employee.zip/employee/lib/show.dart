import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';

class ShowData extends StatelessWidget {
  final String searchKey;
  ShowData({Key? key, required this.searchKey}) : super(key: key);
  final ref = FirebaseDatabase.instance.ref('employees');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Employee Data")),
      body: Column(
        children: [
          SizedBox(height: 20),
          Expanded(
            child: FirebaseAnimatedList(
              query: ref.orderByChild('No').equalTo(int.parse(searchKey)),
              itemBuilder: (context, snapshot, animation, index) {
                return EmployeeCard(snapshot: snapshot);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class EmployeeCard extends StatelessWidget {
  const EmployeeCard({
    Key? key,
    required this.snapshot,
  }) : super(key: key);

  final snapshot;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8.0),
      elevation: 2.0,
      child: ListTile(
        title: GestureDetector(
          onTap: () {
            _showDetails(context, snapshot);
          },
          child: Text(snapshot.child('Name').value.toString()),
        ),
        subtitle: Text('Base Salary: ${snapshot.child('BaseSalary').value.toString()}'),
        trailing: Text('Total Salary: ${snapshot.child('TotalSalary').value.toString()}'),
      ),
    );
  }

  void _showDetails(BuildContext context, DataSnapshot snapshot) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(snapshot.child('Name').value.toString()),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Base Salary: ${snapshot.child('BaseSalary').value.toString()}'),
              Text('Total Salary: ${snapshot.child('TotalSalary').value.toString()}'),
            ],
          ),
          actions: [

            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }
}
