package com.example.employee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
